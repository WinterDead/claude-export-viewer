# Synthetic shared notes

A document-kind artifact whose content is this Markdown file.

- First point
- Second point with **emphasis**

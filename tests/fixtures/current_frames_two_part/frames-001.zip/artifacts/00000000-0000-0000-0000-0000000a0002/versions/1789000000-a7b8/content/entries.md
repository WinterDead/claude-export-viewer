# Reading log

- First synthetic entry
- Second synthetic entry (First draft.)

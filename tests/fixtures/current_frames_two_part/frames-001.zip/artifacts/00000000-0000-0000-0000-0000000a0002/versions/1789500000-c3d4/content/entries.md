# Reading log

- First synthetic entry
- Second synthetic entry (Second draft — the active one.)

# Reading log

- First synthetic entry
- Second synthetic entry (Newest draft, not yet active.)
